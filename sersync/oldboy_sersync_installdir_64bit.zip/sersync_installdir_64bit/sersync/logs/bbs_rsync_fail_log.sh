#errno -1
cd /data0/www/bbs && rsync -aruz -R  --timeout=100 "./bbsbbs.txt" rsync_backup@10.0.0.183::bbs --password-file=/etc/rsync.password >/dev/null 2>&1 

#errno -1
cd /data0/www/bbs && rsync -aruz -R  --timeout=100 "./bbsbbs.txt" rsync_backup@10.0.0.182::bbs --password-file=/etc/rsync.password >/dev/null 2>&1 

#errno -1
cd /data0/www/bbs && rsync -aruz -R  --timeout=100 --delete ./   --include="bbsbbs.txt" --exclude=*  rsync_backup@10.0.0.182::bbs --password-file=/etc/rsync.password >/dev/null 2>&1 

#errno -1
cd /data0/www/bbs && rsync -aruz -R  --timeout=100 --delete ./   --include="bbsbbs.txt" --exclude=*  rsync_backup@10.0.0.183::bbs --password-file=/etc/rsync.password >/dev/null 2>&1 

#errno -1
cd /data0/www/bbs && rsync -aruz -R  --timeout=100 --delete ./   --include="bbs.log" --exclude=*  rsync_backup@10.0.0.182::bbs --password-file=/etc/rsync.password >/dev/null 2>&1 

#errno -1
cd /data0/www/bbs && rsync -aruz -R  --timeout=100 --delete ./   --include="bbs.log" --exclude=*  rsync_backup@10.0.0.183::bbs --password-file=/etc/rsync.password >/dev/null 2>&1 

#errno -1
cd /data0/www/bbs && rsync -aruz -R  --timeout=100 --delete ./   --include="bbs.txt" --exclude=*  rsync_backup@10.0.0.182::bbs --password-file=/etc/rsync.password >/dev/null 2>&1 

#errno -1
cd /data0/www/bbs && rsync -aruz -R  --timeout=100 --delete ./   --include="bbs.txt" --exclude=*  rsync_backup@10.0.0.183::bbs --password-file=/etc/rsync.password >/dev/null 2>&1 

