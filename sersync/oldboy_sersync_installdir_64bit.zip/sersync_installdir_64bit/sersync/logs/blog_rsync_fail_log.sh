#errno -1
cd /data0/www/blog && rsync -aruz -R  --timeout=100 "./blogblog.txt" rsync_backup@10.0.0.182::blog --password-file=/etc/rsync.password >/dev/null 2>&1 

#errno -1
cd /data0/www/blog && rsync -aruz -R  --timeout=100 "./blogblog.txt" rsync_backup@10.0.0.183::blog --password-file=/etc/rsync.password >/dev/null 2>&1 

#errno -1
cd /data0/www/blog && rsync -aruz -R  --timeout=100 --delete ./   --include="blogblog.txt" --exclude=*  rsync_backup@10.0.0.183::blog --password-file=/etc/rsync.password >/dev/null 2>&1 

#errno -1
cd /data0/www/blog && rsync -aruz -R  --timeout=100 --delete ./   --include="blogblog.txt" --exclude=*  rsync_backup@10.0.0.182::blog --password-file=/etc/rsync.password >/dev/null 2>&1 

#errno -1
cd /data0/www/blog && rsync -aruz -R  --timeout=100 --delete ./   --include="blog.log" --exclude=*  rsync_backup@10.0.0.183::blog --password-file=/etc/rsync.password >/dev/null 2>&1 

#errno -1
cd /data0/www/blog && rsync -aruz -R  --timeout=100 --delete ./   --include="blog.log" --exclude=*  rsync_backup@10.0.0.182::blog --password-file=/etc/rsync.password >/dev/null 2>&1 

#errno -1
cd /data0/www/blog && rsync -aruz -R  --timeout=100 --delete ./   --include="blog.txt" --exclude=*  rsync_backup@10.0.0.183::blog --password-file=/etc/rsync.password >/dev/null 2>&1 

#errno -1
cd /data0/www/blog && rsync -aruz -R  --timeout=100 --delete ./   --include="blog.txt" --exclude=*  rsync_backup@10.0.0.182::blog --password-file=/etc/rsync.password >/dev/null 2>&1 

