#errno -1
cd /data0/www/www && rsync -aruz -R  --timeout=100 "./www.txt" rsync_backup@10.0.0.183::www --password-file=/etc/rsync.password >/dev/null 2>&1 

#errno -1
cd /data0/www/www && rsync -aruz -R  --timeout=100 "./www.txt" rsync_backup@10.0.0.182::www --password-file=/etc/rsync.password >/dev/null 2>&1 

